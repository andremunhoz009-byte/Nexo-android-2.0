package com.nexo.android

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.nexo.android.managers.VozManager

class MainActivity : AppCompatActivity() {

    private lateinit var vozManager: VozManager
    private lateinit var btnOuvir: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvResultado: TextView

    companion object {
        private const val REQUEST_RECORD_AUDIO_PERMISSION = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnOuvir = findViewById(R.id.btnOuvir)
        tvStatus = findViewById(R.id.tvStatus)
        tvResultado = findViewById(R.id.tvResultado)

        inicializarVozManager()

        btnOuvir.setOnClickListener {
            if (verificarPermissoes()) {
                vozManager.iniciarEscuta()
            } else {
                solicitarPermissao()
            }
        }
    }

    private fun inicializarVozManager() {
        vozManager = VozManager(
            context = this,
            onResultado = { texto ->
                tvResultado.text = texto
                tvStatus.text = "Aguardando comando..."
            },
            onError = { erro ->
                Toast.makeText(this, erro, Toast.LENGTH_SHORT).show()
                tvStatus.text = "Erro na captura"
            },
            onStatusChange = { status ->
                tvStatus.text = status
            }
        )
    }

    private fun verificarPermissoes(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun solicitarPermissao() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.RECORD_AUDIO),
            REQUEST_RECORD_AUDIO_PERMISSION
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                vozManager.iniciarEscuta()
            } else {
                Toast.makeText(this, "Permissão de áudio negada.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        vozManager.destruir()
    }
}
