package com.nexo.android.managers

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

class VozManager(
    private val context: Context,
    private val onResultado: (String) -> Unit,
    private val onError: (String) -> Unit,
    private val onStatusChange: ((String) -> Unit)? = null
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private val intentReconhecimento: Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
    }

    init {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(crearListener())
            }
        } else {
            onError("Serviço de reconhecimento de voz não disponível neste dispositivo.")
        }
    }

    fun iniciarEscuta() {
        onStatusChange?.invoke("Ouvindo...")
        speechRecognizer?.startListening(intentReconhecimento)
    }

    fun pararEscuta() {
        onStatusChange?.invoke("Processando...")
        speechRecognizer?.stopListening()
    }

    fun destruir() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun crearListener() = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            onStatusChange?.invoke("Pode falar...")
        }

        override fun onBeginningOfSpeech() {
            onStatusChange?.invoke("Capturando voz...")
        }

        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            onStatusChange?.invoke("Processando áudio...")
        }

        override fun onError(error: Int) {
            val mensagemErro = when (error) {
                SpeechRecognizer.ERROR_AUDIO -> "Erro no registro de áudio."
                SpeechRecognizer.ERROR_CLIENT -> "Erro do lado do cliente."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permissão insuficiente."
                SpeechRecognizer.ERROR_NETWORK -> "Erro de rede."
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Tempo limite de rede atingido."
                SpeechRecognizer.ERROR_NO_MATCH -> "Nenhum resultado encontrado."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Serviço ocupado, tente novamente."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Nenhum som capturado."
                else -> "Erro desconhecido ao reconhecer voz."
            }
            onError(mensagemErro)
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!matches.isNullOrEmpty()) {
                onResultado(matches[0])
            } else {
                onError("Nenhum texto reconhecido.")
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!matches.isNullOrEmpty()) {
                onStatusChange?.invoke("Parcial: ${matches[0]}")
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
